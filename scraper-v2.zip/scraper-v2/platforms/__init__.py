from .amazon import AmazonPlatform
from .flipkart import FlipkartPlatform
from .myntra import MyntraPlatform
PLATFORM_HANDLERS = {
    "amazon": AmazonPlatform(),
    "flipkart": FlipkartPlatform(),
    "myntra": MyntraPlatform(),
    # "zepto": ZeptoPlatform(),
}

def get_platform_handler(name: str):
    return PLATFORM_HANDLERS.get(name.lower())
