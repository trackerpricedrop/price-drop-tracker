from .base import ECommercePlatform
from playwright.async_api import Page
from urllib.parse import quote_plus
import time
import traceback

class AmazonPlatform(ECommercePlatform):
    async def scrape_product(self, page: Page, url: str) -> dict:
        result = {
            "title": None,
            "price": None,
            "image": None,
            "error": None,
            "timings": {}
        }

        start = time.time()
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        result["timings"]["goto"] = round(time.time() - start, 2)

        # Title
        start = time.time()
        title = await page.text_content("#productTitle")
        result["title"] = title.strip() if title else "N/A"
        result["timings"]["title"] = round(time.time() - start, 2)

        # Price (safe parsing)
        start = time.time()
        try:
            price_whole = await page.text_content("span.a-price-whole")
            price_fraction = await page.text_content("span.a-price-fraction")

            if price_whole:
                whole = price_whole.strip().replace(",", "").replace(".", "")
                fraction = price_fraction.strip() if price_fraction else "00"
                result["price"] = f"{whole}.{fraction}"
            else:
                result["price"] = "N/A"
        except Exception as e:
            result["price"] = "N/A"
        result["timings"]["price"] = round(time.time() - start, 2)

        # Image
        start = time.time()
        image = await page.get_attribute("#landingImage", "src")
        result["image"] = image if image else "N/A"
        result["timings"]["image"] = round(time.time() - start, 2)

        return result

    async def search(self, page: Page, query: str) -> list:
        raw_results = []
        encoded_query = quote_plus(query)
        url = f"https://www.amazon.in/s?k={encoded_query}"

        await page.goto(url, wait_until="domcontentloaded")
        products = await page.query_selector_all("div[data-component-type='s-search-result']")

        for product in products:
            try:
                # ✅ IMAGE & LINK
                image_block = await product.query_selector('div[data-cy="image-container"] a')
                image = "N/A"
                product_link = "N/A"

                if image_block:
                    img = await image_block.query_selector("img.s-image")
                    image = await img.get_attribute("src") if img else "N/A"
                    product_link = await image_block.get_attribute("href") or "N/A"

                # ✅ TITLE
                title = "N/A"
                title_element = await product.query_selector("h2 span")
                if title_element:
                    title = await title_element.text_content()
                else:
                    fallback_title = await product.query_selector("span.a-text-normal")
                    if fallback_title:
                        title = await fallback_title.text_content()

                # ✅ PRICE (robust parsing)
                price_value = None
                price_whole = await product.query_selector("span.a-price-whole")
                price_fraction = await product.query_selector("span.a-price-fraction")

                if price_whole:
                    try:
                        whole = (await price_whole.text_content()).strip().replace(",", "").replace(".", "")
                        fraction = (await price_fraction.text_content()).strip() if price_fraction else "00"
                        price_value = float(f"{whole}.{fraction}")
                    except Exception as e:
                        print(f"[SKIP] Price parsing error: {e}")
                        continue
                else:
                    continue  # Skip if no price

                # ✅ Validate link and title
                if not product_link.strip() or ("/dp/" not in product_link and "/gp/product/" not in product_link):
                    continue
                if not title.strip():
                    continue

                # ✅ Final Product Data
                full_link = f"https://www.amazon.in{product_link.strip()}" if product_link.startswith("/") else product_link

                product_data = {
                    "title": title.strip(),
                    "product_url": full_link,
                    "image_url": image.strip(),
                    "price": f"{price_value:.2f}",
                    "price_value": price_value
                }

                print("[OK]", product_data)
                raw_results.append(product_data)

                if len(raw_results) >= 5:
                    break

            except Exception as e:
                print(f"[WARN] Skipped product block: {e}")
                traceback.print_exc()
                continue

        return raw_results
