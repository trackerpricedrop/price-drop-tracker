from .base import ECommercePlatform
from playwright.async_api import Page
from urllib.parse import quote_plus
import time
import traceback
import re

class MyntraPlatform(ECommercePlatform):
    async def scrape_product(self, page: Page, url: str) -> dict:
        result = {
            "title": None,
            "price": None,
            "image": None,
            "error": None,
            "timings": {}
        }

        try:
            start = time.time()
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            result["timings"]["goto"] = round(time.time() - start, 2)

            # Title
            start = time.time()
            brand = await page.text_content("h1.pdp-title")
            name = await page.text_content("h1.pdp-name")
            if brand and name:
                result["title"] = f"{brand.strip()} {name.strip()}"
            else:
                result["title"] = "N/A"
            result["timings"]["title"] = round(time.time() - start, 2)

            # Price
            start = time.time()
            price_text = await page.text_content("span.pdp-price strong")
            if price_text:
                price_clean = re.sub(r"[^\d]", "", price_text)
                result["price"] = price_clean
            else:
                result["price"] = "N/A"
            result["timings"]["price"] = round(time.time() - start, 2)

            # Image
            start = time.time()
            image_style = await page.get_attribute(".image-grid-imageContainer .image-grid-image", "style")
            image_url = "N/A"
            if image_style:
                match = re.search(r'url\("(.+?)"\)', image_style)
                if match:
                    image_url = match.group(1)
            result["image"] = image_url
            result["timings"]["image"] = round(time.time() - start, 2)

        except Exception as e:
            result["error"] = str(e)
            traceback.print_exc()

        return result

    async def search(self, page: Page, query: str) -> list:
        raw_results = []
        encoded_query = quote_plus(query)
        url = f"https://www.myntra.com/{encoded_query}?rawQuery={encoded_query}"

        await page.goto(url, wait_until="domcontentloaded")
        products = await page.query_selector_all("li.product-base")

        for product in products:
            try:
                # Image
                image_tag = await product.query_selector("img.img-responsive")
                image = await image_tag.get_attribute("src") if image_tag else "N/A"

                # Title (brand + product name)
                brand_tag = await product.query_selector("h3.product-brand")
                product_name_tag = await product.query_selector("h4.product-product")
                brand = await brand_tag.text_content() if brand_tag else ""
                name = await product_name_tag.text_content() if product_name_tag else ""
                title = f"{brand.strip()} {name.strip()}"

                # Price
                price_tag = await product.query_selector("span.product-discountedPrice")
                if not price_tag:
                    price_tag = await product.query_selector("span.product-strike")
                price_text = await price_tag.text_content() if price_tag else "N/A"
                price_clean = re.sub(r"[^\d]", "", price_text or "")
                price_value = float(price_clean) if price_clean else None

                # URL
                link_tag = await product.query_selector("a")
                href = await link_tag.get_attribute("href") if link_tag else None
                product_url = f"https://www.myntra.com{href}" if href and href.startswith("/") else href

                # Validate
                if not product_url or not title or not price_value:
                    continue

                product_data = {
                    "title": title.strip(),
                    "product_url": product_url.strip(),
                    "image_url": image.strip() if image else "N/A",
                    "price": f"{price_value:.2f}",
                    "price_value": price_value
                }

                print("[OK]", product_data)
                raw_results.append(product_data)

                if len(raw_results) >= 5:
                    break

            except Exception as e:
                print(f"[WARN] Skipped product block: {e}")
                traceback.print_exc()
                continue

        return raw_results
