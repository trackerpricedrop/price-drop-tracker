import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import SignIn from './routes/SignIn'
import Register from './routes/Register'

function App() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <nav className="space-x-4 mb-8">
        <Link className="text-blue-600 hover:underline" to="/signin">Sign In</Link>
        <Link className="text-blue-600 hover:underline" to="/register">Register</Link>
      </nav>
      <Routes>
        <Route path="/signin" element={<SignIn />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  )
}

export default App
