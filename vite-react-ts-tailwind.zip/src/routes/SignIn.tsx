import React from 'react'

function SignIn() {
  return (
    <div className="p-6 max-w-sm bg-white rounded shadow">
      <h1 className="text-xl font-bold mb-4">Sign In</h1>
      <input className="border p-2 w-full mb-4" type="email" placeholder="Email" />
      <input className="border p-2 w-full mb-4" type="password" placeholder="Password" />
      <button className="bg-blue-600 text-white px-4 py-2 rounded w-full">Sign In</button>
    </div>
  )
}

export default SignIn
